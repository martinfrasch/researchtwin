"""MCP server for ResearchTwin inter-agentic research discovery."""

__version__ = "0.1.0"
