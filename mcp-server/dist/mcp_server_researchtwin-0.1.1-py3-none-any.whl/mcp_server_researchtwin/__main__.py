"""Allow running as `python -m mcp_server_researchtwin`."""

from .server import main

main()
